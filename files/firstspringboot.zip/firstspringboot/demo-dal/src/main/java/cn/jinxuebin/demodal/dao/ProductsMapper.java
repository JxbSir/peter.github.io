package cn.jinxuebin.demodal.dao;

import cn.jinxuebin.demodal.model.Products;
import org.springframework.stereotype.Repository;
import org.apache.ibatis.annotations.Mapper;

@Repository
@Mapper
public interface ProductsMapper {
    int deleteByPrimaryKey(Integer itemid);

    int insert(Products record);

    int insertSelective(Products record);

    Products selectByPrimaryKey(Integer itemid);

    int updateByPrimaryKeySelective(Products record);

    int updateByPrimaryKey(Products record);
}