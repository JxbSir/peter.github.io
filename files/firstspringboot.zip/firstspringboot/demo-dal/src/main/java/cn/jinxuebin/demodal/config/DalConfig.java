package cn.jinxuebin.demodal.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.mybatis.spring.annotation.MapperScan;

/**
 * @author Peter
 * @description DAL配置类
 * @data 2019-02-20
 */

@Configuration
@MapperScan(basePackages = "cn.jinxuebin.demodal.dao")
@PropertySource(value= {"classpath:application-dal.properties"})
public class DalConfig {
}
