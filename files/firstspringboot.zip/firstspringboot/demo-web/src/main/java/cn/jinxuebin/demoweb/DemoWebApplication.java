package cn.jinxuebin.demoweb;

import cn.jinxuebin.demobiz.config.BizConfig;
import cn.jinxuebin.demodal.config.DalConfig;
import cn.jinxuebin.demoshare.IProductsService;
import cn.jinxuebin.demoshare.bo.ProductsBO;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.mysql.cj.xdevapi.JsonArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@Import({BizConfig.class, DalConfig.class})
public class DemoWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoWebApplication.class, args);
	}


	@Autowired
	private IProductsService service;

	@RequestMapping("/book")
	public String home(@RequestParam("id") int id) {
		ProductsBO bo = service.getProductById(id);
		return JSONValue.toJSONString(bo);
	}

}
