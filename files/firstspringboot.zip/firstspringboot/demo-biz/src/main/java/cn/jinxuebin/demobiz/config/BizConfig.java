package cn.jinxuebin.demobiz.config;

import org.springframework.context.annotation.ComponentScan;

/**
 * @author Peter
 * @description
 * @data 2019-02-20
 */

@ComponentScan(basePackages = "cn.jinxuebin.demobiz")
public class BizConfig {
}
