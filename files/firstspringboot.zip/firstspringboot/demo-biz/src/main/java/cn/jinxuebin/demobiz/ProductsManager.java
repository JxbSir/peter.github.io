package cn.jinxuebin.demobiz;

import cn.jinxuebin.demodal.dao.ProductsMapper;
import cn.jinxuebin.demodal.model.Products;
import cn.jinxuebin.demoshare.bo.ProductsBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Peter
 * @description 商品业务类
 * @data 2019-02-20
 */

@Service
public class ProductsManager {

    @Autowired
    private ProductsMapper productsMapper;

    public ProductsBO getProductById(int id) {
        Products dao = productsMapper.selectByPrimaryKey(id);

        ProductsBO bo = new ProductsBO();
        bo.setItemid(dao.getItemid());
        bo.setDesc(dao.getItemdesc());
        bo.setName(dao.getItemname());
        bo.setPrice(dao.getPrice());
        bo.setShopid(dao.getShopid());

        return bo;
    }

}
