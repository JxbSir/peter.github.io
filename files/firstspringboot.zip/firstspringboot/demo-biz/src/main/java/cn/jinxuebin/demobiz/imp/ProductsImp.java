package cn.jinxuebin.demobiz.imp;


import cn.jinxuebin.demobiz.ProductsManager;
import cn.jinxuebin.demoshare.IProductsService;
import cn.jinxuebin.demoshare.bo.ProductsBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Peter
 * @description ProductsService实现类
 * @data 2019-02-20
 */

@Service
public class ProductsImp implements IProductsService {

    @Autowired
    private ProductsManager productsManager;

    @Override
    public ProductsBO getProductById(int id) {
        return productsManager.getProductById(id);
    }
}
