package cn.jinxuebin.demoshare;

import cn.jinxuebin.demoshare.bo.ProductsBO;

/**
 * @author Peter
 * @description Products业务接口类
 * @data 2019-02-20
 */

public interface IProductsService {

    ProductsBO getProductById(int id);

}
