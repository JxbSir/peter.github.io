module.exports = [
    require('./01-add-themes-permissions')
];
