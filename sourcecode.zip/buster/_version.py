__version_info__ = (0, 1, 3)
__version__ = '.'.join(map(str, __version_info__))
